#!/bin/bash
make
./EchoTestServer --config=EchoTestServer.conf
