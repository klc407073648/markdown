#!/bin/bash
make
./EchoClientServer --config=EchoClientServer.conf
