#!/bin/bash
make
./ZipkinTraceServer --config=ZipkinTraceServer.conf
