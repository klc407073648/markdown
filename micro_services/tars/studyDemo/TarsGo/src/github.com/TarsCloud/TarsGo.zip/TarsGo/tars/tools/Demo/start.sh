#!/bin/bash
make
./_SERVER_ --config=config.conf
