#!/bin/bash
make
./ZipkinTraceClient --config=ZipkinTraceClient.conf
