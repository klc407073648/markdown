#!/bin/bash
./ContextTestServer --config=ContextTestServer.conf
