package main

//VERSION version of the tars2go tools.
const VERSION = "1.1.4"
