#!/bin/bash
make
./CustomProtoServer --config=CustomProtoServer.conf
