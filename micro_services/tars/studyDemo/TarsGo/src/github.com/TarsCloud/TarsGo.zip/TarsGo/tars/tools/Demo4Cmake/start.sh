#!/bin/bash
make
./build/_SERVER_ --config=config.conf
